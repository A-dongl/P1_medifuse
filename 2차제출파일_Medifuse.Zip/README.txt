SourceCode.txt 파일은 ipynb 파일로 작성되어있습니다.
인터프리터 언어이지만 한번만 실행하면 모두 돌아가도록 작성되어있기 때문에
ipynb 파일의 한 셀이나 py 파일로 한번만 실행하면 auroc에 C-statistics 값이 저장되어있습니다.

파일을 돌리실 때, 유의할 점은
 TrainSet_1차.csv와 Validation_2차.csv 파일이 모두 실행하는 소스코드와 같은 위치에서 실행되어야 합니다.

추가적으로 2차 데이터를 활용한 결과물의 값은 1차 때와 같이 C-statistics.txt 파일에 저장해 두었습니다.